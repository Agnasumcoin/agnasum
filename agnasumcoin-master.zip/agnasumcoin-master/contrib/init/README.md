Sample configuration files for:

SystemD: omegacoind.service
Upstart: omegacoind.conf
OpenRC:  omegacoind.openrc
         omegacoind.openrcconf
CentOS:  omegacoind.init
OS X:    org.omegacoin.omegacoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
